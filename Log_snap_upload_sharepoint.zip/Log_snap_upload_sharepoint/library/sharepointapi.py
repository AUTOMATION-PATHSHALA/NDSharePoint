'''module: sharepointapi'''
import json
import requests
from ansible.module_utils.basic import AnsibleModule
import sys
import os
import time
import msal
import json as simplejson

def get_jwt_access_token(inputParam):   
    
    graphURI = "https://graph.microsoft.com"
    clientID = inputParam['clientID'] #"1e5d6a5c-9b7c-4293-a9d8-543e30784941"    
    tenantID= inputParam['tenantID']  
    authority = "https://login.microsoftonline.com/" + tenantID
    scope = "https://graph.microsoft.com/.default"
    thumbprint = inputParam['thumbprint']
    certfile = inputParam['certfile']#"juudankaicert.pem"
    app = msal.ConfidentialClientApplication(clientID, authority=authority,  client_credential={"thumbprint": thumbprint, "private_key": open(certfile).read()}) 
    response = app.acquire_token_for_client(scopes=scope)
    #response = requests.post(authentication_url, params)
    #temp_response = response.json()
    access_token = response['access_token']
    return False, response

def get_fileOrfolder_info_by_path(inputParam):
    item_path=inputParam['fileOrFolderPath']  
    driveId= inputParam['driveId'] 
    access_token=inputParam['accessToken'] 
    url="https://graph.microsoft.com/v1.0/drives/"+driveId+"/root:/"+item_path
    header= {'Authorization': "Bearer {}".format(access_token)}    
    response=requests.get(url,headers=header)
     
    if (response.status_code == 200):
      return False , response.content
    else:
      return True, response
 
def list_item_in_folder(inputParam):
    folderId=inputParam['folderId']  
    driveId= inputParam['driveId'] 
    access_token=inputParam['accessToken']
    template_url="https://graph.microsoft.com/v1.0/drives/"+driveId+"/##ItemID##/children"
    url="https://api.box.com/2.0/folders/"+folderId+"/items"
    if (folderId == "") or (len(folderId) == 0) or (folderId is None):
        url=template_url.replace("##ItemID##","root")
    else:
        url=template_url.replace("##ItemID##","items/"+folderId)

    header= {'Authorization': "Bearer {}".format(access_token)}    
    response=requests.get(url,headers=header)
    
    if (response.status_code == 200):
      return False , response.content
    else:
      return True, response.content

def upload_new_file(inputParam):
    source_folder_path= inputParam['sourceFolderPath']  
    source_file_name= inputParam['sourceFilename'] 
    destination_folder_Id=inputParam['folderId']
    driveId= inputParam['driveId'] 
    access_token= inputParam['accessToken'] 
    header= {'Authorization': "Bearer {}".format(access_token)}
    
    template_url="https://graph.microsoft.com/v1.0/drives/"+driveId

    if (destination_folder_Id == "") or (len(destination_folder_Id) == 0) or (destination_folder_Id is None):
        url=template_url + "/root:/"+source_file_name+":/content"
    else:
        url=template_url + "/items/"+destination_folder_Id+":/"+source_file_name+":/content"    
    
    files = {'file': (source_file_name, open(source_folder_path,'rb'))}    
    
    response=requests.put(url,files=files,headers=header)
    
    if (response.status_code == 200 or response.status_code == 201):
        return False , response.text   
    else:
       return True, response.content

def upload_large_file(inputParam):    
    source_folder_path= inputParam['sourceFolderPath']  
    source_file_name= inputParam['sourceFilename'] 
    destination_folder_Id=inputParam['folderId']
    driveId= inputParam['driveId'] 
    access_token= inputParam['accessToken'] 
    header= {
            'Authorization': "Bearer {}".format(access_token),
            'Content-type': 'text/plain'
    }
    
    
    template_url="https://graph.microsoft.com/v1.0/drives/"+driveId

    if (destination_folder_Id == "") or (len(destination_folder_Id) == 0) or (destination_folder_Id is None):
        url=template_url + "/root:/"+source_file_name+":/createUploadSession"
    else:        
        url=template_url + "/items/"+destination_folder_Id+":/"+source_file_name+":/createUploadSession"   
    
        
    response= requests.post(url, headers=header)
    upload_session = response.json()
    upload_url= upload_session['uploadUrl']

    st = os.stat(source_folder_path)
    size = st.st_size    
    CHUNK_SIZE= 10485760
    chunks = int(size / CHUNK_SIZE) + 1 if size % CHUNK_SIZE > 0 else 0
    with open (source_folder_path, 'rb') as fd:
        start =0
        for chunk_num in range(chunks):
            chunk = fd.read(CHUNK_SIZE)
            bytes_read = len(chunk)
            #upload_range = f'bytes {start}-{start + bytes_read - 1}/{size}'
            upload_range = bytes {start}-{start + bytes_read - 1}/{size}
            #print(f'chunk: {chunk_num} bytes read: {bytes_read} upload range: {upload_range}')
            response=requests.put(
                    upload_url,
                    headers={
                        'Content-Length': str(bytes_read),
                        'Content-Range': upload_range,
                    },
                    data=chunk
            )
            #response.raise_for_status()
            start += bytes_read

    
    if (response.status_code == 200 or response.status_code == 201):
        return False , response.text   
    else:
       return True, response.content  

def download_file(inputParam):
    source_file_id=inputParam['fileId']
    source_file_name=inputParam['sourceFilename']
    destination_folder_path=inputParam['saveLocationPath'] 
    driveId=inputParam['driveId'] 
    #destination_file_Id=inputParam['fileId']
    access_token= inputParam['accessToken'] 
    url="https://graph.microsoft.com/v1.0/drives/"+driveId+"/items/"+source_file_id+"/content"        
   
    header = {
    'Authorization': 'Bearer ' + access_token,
    'Content-Type': 'application/json'
    }

   
    response= requests.get(url,headers=header)    
    if (response.status_code == 200 or response.status_code == 201):
        with open (os.path.join(destination_folder_path,source_file_name),'wb') as _f:
            _f.write(response.content)
        return False , response    
    else:
       return True, response

def copy_file(inputParam):    
    source_filename = inputParam['sourceFilename']    
    driveId = inputParam['driveId']
    source_file_Id = inputParam['fileId']
    new_parent_folder_id = inputParam['folderId']
    access_token = inputParam['accessToken'] 
    
    url="https://graph.microsoft.com/v1.0/drives/"+driveId+"/items/" +source_file_Id +"/copy"  
    data = {'parentReference': {
    'id': new_parent_folder_id
    },
    'name': source_filename
     }
    header={'Authorization': 'Bearer ' + access_token, 'Content-Type': 'application/json'}
    response=requests.post(url, json.dumps(data).encode("utf-8"), headers=header)
    if (response.status_code == 202):
        return False , response.status_code    
    else:
       return True, response

def move_file(inputParam):    
    source_file_Id=inputParam['fileId']
    source_filename= inputParam['sourceFilename']
    driveId= inputParam['driveId']
    new_parent_folder_id= inputParam['folderId']
    access_token= inputParam['accessToken'] 
   
    url="https://graph.microsoft.com/v1.0/drives/"+driveId+"/items/" +source_file_Id

    data = {'parentReference': {
    'id': new_parent_folder_id
    },
    'name': source_filename
     }
    
    header={'Authorization': 'Bearer ' + access_token, 'Content-Type': 'application/json'}
    response=requests.put(url, json.dumps(data).encode("utf-8"), headers=header)
    
    if (response.status_code == 200 or response.status_code == 201):
        return False , response.status_code    
    else:
       return True, response

def rename_file(inputParam):    
    new_file_name =inputParam['newFilename']    
    driveId= inputParam['driveId']
    source_file_Id = inputParam['fileId']
    access_token = inputParam['accessToken'] 
    data = {
        'name': new_file_name
    }
    
    url="https://graph.microsoft.com/v1.0/drives/"+driveId+"/items/" +source_file_Id

    header={'Authorization': 'Bearer ' + access_token, 'Content-Type': 'application/json'}

    response=requests.put(url, json.dumps(data).encode("utf-8"), headers=header)

    if (response.status_code == 200 or response.status_code == 201):
        return False , response.status_code   
    else:
       return True, response


def upload_file_version(inputParam):
    source_folder_path=inputParam['sourceFolderPath']
    source_file_name=inputParam['sourceFilename']    
    driveId=inputParam['driveId']
    destination_file_Id=inputParam['fileId']
    access_token=inputParam['accessToken'] 
    
    url="https://graph.microsoft.com/v1.0/drives/"+driveId+"/items/"+destination_file_Id+"/content"    
    files = {'file': (source_file_name, open(source_folder_path,'rb'))}
    header= {'Authorization': "Bearer {}".format(access_token)}
    
    response=requests.put(url,files=files,headers=header)
    if (response.status_code == 200 or response.status_code == 201):
        return False , response.content    
    else:
        return True, response.content

def main():
  
    fields = {
        "sourceFolderPath": {"required": False, "type": "str"},
        "sourceFilename": {"required": False, "type": "str"},
        "newFilename": {"required": False, "type": "str"},
        "folderId": {"required": False, "type": "str"},
        "driveId": {"required": False, "type": "str"},
        "fileOrFolderPath": {"required": False, "type": "str"},
        "accessToken": {"required": False, "type": "str"},
        "fileId": {"required": False, "type": "str"},
        "clientID": {"required": False, "type": "str"}, 
        "thumbprint": {"required": False, "type": "str"},
	    "certfile": {"required": False, "type": "str"},
        "tenantID": {"required": False, "type": "str"}, 
        "saveLocationPath": {"required": False, "type": "str"},    
        "action": { 
            "default": "itemsinfolder",
            "choices": ['uploadfile','uploadlargefile','renamefile','movefile','copyfile','uploadfileversion','getfileOrfolderinfobypath','getjwtaccesstoken','itemsinfolder','downloadfile'],
            "type": "str"
            },
    }

    choice_map = {
         "uploadfile": upload_new_file,
         "uploadlargefile": upload_large_file,
         "uploadfileversion": upload_file_version,
         "getjwtaccesstoken": get_jwt_access_token,
         "itemsinfolder": list_item_in_folder,
         "downloadfile": download_file,
         "renamefile": rename_file,
         "movefile": move_file,
         "copyfile": copy_file,
         "getfileOrfolderinfobypath": get_fileOrfolder_info_by_path,
    }

    module = AnsibleModule(argument_spec=fields)
    is_error, response = choice_map.get(module.params['action'])(module.params)
    if not is_error:
        module.exit_json(changed=True, msg="success",meta=response)
    else:
        module.fail_json(changed=False,msg="Failed", meta=response)
if __name__=='__main__':
     main()
   #access_token=get_jwt_access_token()
   #print(access_token)


